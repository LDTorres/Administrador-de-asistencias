<?php
    $key = 'm.iuteb';
?>