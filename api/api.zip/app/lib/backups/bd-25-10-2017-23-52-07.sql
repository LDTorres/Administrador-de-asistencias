-- MySQL Script generado por Administrador de Asistencias 
-- 25-10-2017 23-52-07 
-- Version: 1.0 
-- MySQL Admin 

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES'; 


 -- ----------------------------------------------------- 
 -- Schema iuteb_asignaturas 
 -- 
 -- Base de datos para aplicacion de asistencias del IUTEB 
 -- 
 -- Luis Torres -- 
 -- Adrian Flores -- 
 -- Michel Novellino 
 
 CREATE SCHEMA IF NOT EXISTS `iuteb_asignaturas`;
 USE `iuteb_asignaturas`; 

 -- ----------------------------------------------------- 
 -- Table `Iuteb_asignaturas`.`alumnos_has_asistencias` 
 -- ----------------------------------------------------- 

DROP TABLE IF EXISTS alumnos_has_asistencias;

CREATE TABLE `alumnos_has_asistencias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_seccion` int(11) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `asistio` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `a_has_id_usuarios_idx` (`id_usuario`),
  KEY `a_has_id_seccion_idx` (`id_seccion`),
  CONSTRAINT `a_has_id_seccion` FOREIGN KEY (`id_seccion`) REFERENCES `secciones` (`id_seccion`),
  CONSTRAINT `a_has_id_usuarios` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- ----------------------------------------------------- 
 -- Table `Iuteb_asignaturas`.`alumnos_has_secciones` 
 -- ----------------------------------------------------- 

DROP TABLE IF EXISTS alumnos_has_secciones;

CREATE TABLE `alumnos_has_secciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(20) DEFAULT NULL,
  `id_seccion` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `al_has_id_usuario_idx` (`id_usuario`),
  KEY `al_has_s_id_seccion_idx` (`id_seccion`),
  CONSTRAINT `al_has_s_id_seccion` FOREIGN KEY (`id_seccion`) REFERENCES `secciones` (`id_seccion`) ON UPDATE CASCADE,
  CONSTRAINT `al_has_s_id_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- ----------------------------------------------------- 
 -- Table `Iuteb_asignaturas`.`app_config` 
 -- ----------------------------------------------------- 

DROP TABLE IF EXISTS app_config;

CREATE TABLE `app_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) DEFAULT NULL,
  `version` varchar(45) DEFAULT NULL,
  `fecha_creaccion` datetime DEFAULT NULL,
  `descripcion` varchar(900) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO app_config VALUES("1","GATE","0.1","2017-10-25 05:00:00","Administrador de Asistencias");

-- ----------------------------------------------------- 
 -- Table `Iuteb_asignaturas`.`asignaturas` 
 -- ----------------------------------------------------- 

DROP TABLE IF EXISTS asignaturas;

CREATE TABLE `asignaturas` (
  `id_asignatura` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_asig` varchar(45) DEFAULT NULL,
  `trimestre` int(11) DEFAULT NULL,
  `id_malla` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_asignatura`),
  KEY `m_id_malla_idx` (`id_malla`),
  CONSTRAINT `m_id_malla` FOREIGN KEY (`id_malla`) REFERENCES `malla_curricular` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO asignaturas VALUES("1","Formacion Critica","1","1");
INSERT INTO asignaturas VALUES("2","Matemáticas","1","1");

-- ----------------------------------------------------- 
 -- Table `Iuteb_asignaturas`.`basededatos` 
 -- ----------------------------------------------------- 

DROP TABLE IF EXISTS basededatos;

CREATE TABLE `basededatos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(100) DEFAULT NULL,
  `date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filename_UNIQUE` (`filename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO basededatos VALUES("1","bd-iuteb-25-10-2017-23-52-07.sql","2017-10-25 17:52:07");

-- ----------------------------------------------------- 
 -- Table `Iuteb_asignaturas`.`malla_curricular` 
 -- ----------------------------------------------------- 

DROP TABLE IF EXISTS malla_curricular;

CREATE TABLE `malla_curricular` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO malla_curricular VALUES("1","Informatica");
INSERT INTO malla_curricular VALUES("2","Informatica");
INSERT INTO malla_curricular VALUES("3","Geo Ciencias");

-- ----------------------------------------------------- 
 -- Table `Iuteb_asignaturas`.`publicaciones` 
 -- ----------------------------------------------------- 

DROP TABLE IF EXISTS publicaciones;

CREATE TABLE `publicaciones` (
  `id_publicacion` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(45) DEFAULT NULL,
  `descripcion` varchar(45) DEFAULT NULL,
  `id_seccion` int(11) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `fecha_publicacion` datetime DEFAULT CURRENT_TIMESTAMP,
  `nombre_archivo` varchar(100) DEFAULT 'grabatar.jpg',
  PRIMARY KEY (`id_publicacion`),
  KEY `p_id_usuario_idx` (`id_usuario`),
  KEY `p_id_seccion_idx` (`id_seccion`),
  CONSTRAINT `p_id_seccion` FOREIGN KEY (`id_seccion`) REFERENCES `secciones` (`id_seccion`) ON UPDATE CASCADE,
  CONSTRAINT `p_id_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- ----------------------------------------------------- 
 -- Table `Iuteb_asignaturas`.`secciones` 
 -- ----------------------------------------------------- 

DROP TABLE IF EXISTS secciones;

CREATE TABLE `secciones` (
  `id_seccion` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) DEFAULT NULL,
  `id_asignatura` int(11) DEFAULT NULL,
  `codigo` varchar(45) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_seccion`),
  KEY `s_id_materia_idx` (`id_asignatura`),
  KEY `s_id_usuario_idx` (`id_usuario`),
  CONSTRAINT `s_id_asignatura` FOREIGN KEY (`id_asignatura`) REFERENCES `asignaturas` (`id_asignatura`) ON UPDATE CASCADE,
  CONSTRAINT `s_id_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO secciones VALUES("1","INF-IV-3N","1","dd32092c","2");

-- ----------------------------------------------------- 
 -- Table `Iuteb_asignaturas`.`user_has_preferencias` 
 -- ----------------------------------------------------- 

DROP TABLE IF EXISTS user_has_preferencias;

CREATE TABLE `user_has_preferencias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) DEFAULT NULL,
  `cant_posts` int(11) DEFAULT '5',
  `color_ui` varchar(45) DEFAULT 'positive',
  `recibir_notificaciones` int(11) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_usuario_UNIQUE` (`id_usuario`),
  CONSTRAINT `uhp_id_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO user_has_preferencias VALUES("1","2","5","positive","1");

-- ----------------------------------------------------- 
 -- Table `Iuteb_asignaturas`.`usuarios` 
 -- ----------------------------------------------------- 

DROP TABLE IF EXISTS usuarios;

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(45) DEFAULT NULL,
  `contrasena` int(11) DEFAULT NULL,
  `nombre_completo` varchar(45) DEFAULT NULL,
  `cedula` int(11) DEFAULT NULL,
  `correo` varchar(45) DEFAULT NULL,
  `fecha_ingreso` datetime DEFAULT CURRENT_TIMESTAMP,
  `telefono` int(11) DEFAULT NULL,
  `foto_perfil` varchar(450) DEFAULT 'grabatar.jpg',
  `id_malla` int(11) DEFAULT NULL,
  `estado` enum('0','1') DEFAULT '1',
  `tipo` enum('Estudiante','Administrador','Profesor') DEFAULT 'Estudiante',
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `correo_UNIQUE` (`correo`),
  UNIQUE KEY `usuario_UNIQUE` (`usuario`),
  KEY `user_id_malla_idx` (`id_malla`),
  CONSTRAINT `user_id_malla` FOREIGN KEY (`id_malla`) REFERENCES `malla_curricular` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO usuarios VALUES("1","Admin","1","Administrador","123456789","prog@gmail.com","2017-10-25 17:18:11","123456789","grabatar.jpg","1","1","Administrador");
INSERT INTO usuarios VALUES("2","Luis","12345","Luis Torres","12345789","f@g.com","2017-10-25 17:22:17","123459","grabatar.jpg","1","1","Estudiante");

