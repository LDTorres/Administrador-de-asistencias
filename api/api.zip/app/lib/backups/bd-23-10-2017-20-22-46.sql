-- MySQL Script generado por Administrador de Asistencias 
-- 23-10-2017 20-22-46 
-- Version: 1.0 
-- MySQL Admin 

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES'; 


 -- ----------------------------------------------------- 
 -- Schema iuteb_asignaturas 
 -- 
 -- Base de datos para aplicacion de asistencias del IUTEB 
 -- 
 -- Luis Torres -- 
 -- Adrian Flores -- 
 -- Michel Novellino 
 
 CREATE SCHEMA IF NOT EXISTS `iuteb_asignaturas`;
 USE `iuteb_asignaturas`; 

 -- ----------------------------------------------------- 
 -- Table `Iuteb_asignaturas`.`alumnos_has_asistencias` 
 -- ----------------------------------------------------- 

DROP TABLE IF EXISTS alumnos_has_asistencias;

CREATE TABLE `alumnos_has_asistencias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_seccion` int(11) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `asistio` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `a_has_id_usuarios_idx` (`id_usuario`),
  KEY `a_has_id_seccion_idx` (`id_seccion`),
  CONSTRAINT `a_has_id_seccion` FOREIGN KEY (`id_seccion`) REFERENCES `secciones` (`id_seccion`),
  CONSTRAINT `a_has_id_usuarios` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

INSERT INTO alumnos_has_asistencias VALUES("38","1","1","2017-10-20","1");
INSERT INTO alumnos_has_asistencias VALUES("39","1","2","2017-09-28","0");
INSERT INTO alumnos_has_asistencias VALUES("40","1","3","2017-09-28","1");
INSERT INTO alumnos_has_asistencias VALUES("41","1","4","2017-09-28","0");
INSERT INTO alumnos_has_asistencias VALUES("42","1","1","2017-09-07","1");
INSERT INTO alumnos_has_asistencias VALUES("43","1","2","2017-09-07","0");
INSERT INTO alumnos_has_asistencias VALUES("44","1","3","2017-09-07","1");
INSERT INTO alumnos_has_asistencias VALUES("45","1","4","2017-09-07","0");
INSERT INTO alumnos_has_asistencias VALUES("46","1","1","2017-09-29","1");
INSERT INTO alumnos_has_asistencias VALUES("47","1","2","2017-09-29","1");
INSERT INTO alumnos_has_asistencias VALUES("48","1","3","2017-09-29","0");
INSERT INTO alumnos_has_asistencias VALUES("49","1","4","2017-09-29","0");
INSERT INTO alumnos_has_asistencias VALUES("50","1","1","2017-10-26","0");
INSERT INTO alumnos_has_asistencias VALUES("51","1","2","2017-10-26","1");
INSERT INTO alumnos_has_asistencias VALUES("52","1","3","2017-10-26","1");
INSERT INTO alumnos_has_asistencias VALUES("53","1","4","2017-10-26","0");

-- ----------------------------------------------------- 
 -- Table `Iuteb_asignaturas`.`alumnos_has_secciones` 
 -- ----------------------------------------------------- 

DROP TABLE IF EXISTS alumnos_has_secciones;

CREATE TABLE `alumnos_has_secciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(20) DEFAULT NULL,
  `id_seccion` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `al_has_id_usuario_idx` (`id_usuario`),
  KEY `al_has_s_id_seccion_idx` (`id_seccion`),
  CONSTRAINT `al_has_s_id_seccion` FOREIGN KEY (`id_seccion`) REFERENCES `secciones` (`id_seccion`) ON UPDATE CASCADE,
  CONSTRAINT `al_has_s_id_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO alumnos_has_secciones VALUES("1","1","1");
INSERT INTO alumnos_has_secciones VALUES("11","2","1");
INSERT INTO alumnos_has_secciones VALUES("12","3","1");
INSERT INTO alumnos_has_secciones VALUES("13","4","1");
INSERT INTO alumnos_has_secciones VALUES("17","1","3");

-- ----------------------------------------------------- 
 -- Table `Iuteb_asignaturas`.`app_config` 
 -- ----------------------------------------------------- 

DROP TABLE IF EXISTS app_config;

CREATE TABLE `app_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) DEFAULT NULL,
  `version` varchar(45) DEFAULT NULL,
  `fecha_creaccion` datetime DEFAULT NULL,
  `descripcion` varchar(900) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO app_config VALUES("1","IUTEB GATE","0.1","2017-10-23 02:15:00","Administrador de asistencias Y Asignaturas");

-- ----------------------------------------------------- 
 -- Table `Iuteb_asignaturas`.`asignaturas` 
 -- ----------------------------------------------------- 

DROP TABLE IF EXISTS asignaturas;

CREATE TABLE `asignaturas` (
  `id_asignatura` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_asig` varchar(45) DEFAULT NULL,
  `trimestre` int(11) DEFAULT NULL,
  `id_malla` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_asignatura`),
  KEY `m_id_malla_idx` (`id_malla`),
  CONSTRAINT `m_id_malla` FOREIGN KEY (`id_malla`) REFERENCES `malla_curricular` (`id_malla`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO asignaturas VALUES("1","Formacion Critica","1","2");
INSERT INTO asignaturas VALUES("8","Prueba","1","2");

-- ----------------------------------------------------- 
 -- Table `Iuteb_asignaturas`.`basededatos` 
 -- ----------------------------------------------------- 

DROP TABLE IF EXISTS basededatos;

CREATE TABLE `basededatos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(100) DEFAULT NULL,
  `date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filename_UNIQUE` (`filename`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO basededatos VALUES("1","bd-iuteb-23-10-2017-20-20-59.sql","2017-10-23 14:20:59");
INSERT INTO basededatos VALUES("2","bd-iuteb-23-10-2017-20-21-01.sql","2017-10-23 14:21:01");
INSERT INTO basededatos VALUES("3","bd-iuteb-23-10-2017-20-22-46.sql","2017-10-23 14:22:46");

-- ----------------------------------------------------- 
 -- Table `Iuteb_asignaturas`.`malla_curricular` 
 -- ----------------------------------------------------- 

DROP TABLE IF EXISTS malla_curricular;

CREATE TABLE `malla_curricular` (
  `id_malla` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_malla`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO malla_curricular VALUES("1","Inform�tica");
INSERT INTO malla_curricular VALUES("2","Mmai");

-- ----------------------------------------------------- 
 -- Table `Iuteb_asignaturas`.`publicaciones` 
 -- ----------------------------------------------------- 

DROP TABLE IF EXISTS publicaciones;

CREATE TABLE `publicaciones` (
  `id_publicacion` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(45) DEFAULT NULL,
  `descripcion` varchar(45) DEFAULT NULL,
  `id_seccion` int(11) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `fecha_publicacion` datetime DEFAULT CURRENT_TIMESTAMP,
  `nombre_archivo` varchar(100) DEFAULT 'grabatar.jpg',
  PRIMARY KEY (`id_publicacion`),
  KEY `p_id_usuario_idx` (`id_usuario`),
  KEY `p_id_seccion_idx` (`id_seccion`),
  CONSTRAINT `p_id_seccion` FOREIGN KEY (`id_seccion`) REFERENCES `secciones` (`id_seccion`) ON UPDATE CASCADE,
  CONSTRAINT `p_id_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO publicaciones VALUES("2","Post 1","Descripcion","1","1","2017-09-24 21:20:50","grabatar.jpg");
INSERT INTO publicaciones VALUES("3","Post 2","Esta es una prueba","2","1","2017-09-24 21:26:33","grabatar.jpg");
INSERT INTO publicaciones VALUES("4","Post 2","Esta es una prueba","2","1","2017-09-24 21:30:59","grabatar.jpg");
INSERT INTO publicaciones VALUES("5","Post 4","Esta es una prueba","1","1","2017-09-24 21:36:11","grabatar.jpg");
INSERT INTO publicaciones VALUES("6","Post 5","Esta es una prueba","2","1","2017-09-24 21:36:25","grabatar.jpg");
INSERT INTO publicaciones VALUES("7","Post 6","Esta es una prueba","1","1","2017-09-24 21:37:01","grabatar.jpg");
INSERT INTO publicaciones VALUES("14","Hola michel","Estas gordito","1","1","2017-09-29 14:53:29","grabatar.jpg");

-- ----------------------------------------------------- 
 -- Table `Iuteb_asignaturas`.`secciones` 
 -- ----------------------------------------------------- 

DROP TABLE IF EXISTS secciones;

CREATE TABLE `secciones` (
  `id_seccion` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) DEFAULT NULL,
  `id_asignatura` int(11) DEFAULT NULL,
  `codigo` varchar(45) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_seccion`),
  KEY `s_id_materia_idx` (`id_asignatura`),
  KEY `s_id_usuario_idx` (`id_usuario`),
  CONSTRAINT `s_id_asignatura` FOREIGN KEY (`id_asignatura`) REFERENCES `asignaturas` (`id_asignatura`) ON UPDATE CASCADE,
  CONSTRAINT `s_id_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO secciones VALUES("1","INF-V-3N","1","abcde","2");
INSERT INTO secciones VALUES("2","INF-III-1M","1","sd","2");
INSERT INTO secciones VALUES("3","4G-TF-VV","1","11","1");
INSERT INTO secciones VALUES("4","4G-TF-VVh","1","e192626289c38d5aa2e128a5144d6b70","1");
INSERT INTO secciones VALUES("5","ksjkdsj","1","06c331069780f1d7ad793c44e18ff9b1","1");
INSERT INTO secciones VALUES("6","ksjkdsjkjn","1","f608c6344edeb1b53a9da27d6ab14cdc","3");
INSERT INTO secciones VALUES("7","","","8920686f64406d5806a3fb960ad16a43","1");
INSERT INTO secciones VALUES("8","","","e45163291644d3c170b47ff2e12691fc","1");
INSERT INTO secciones VALUES("9","","","3ab61522693cd6d18955235dba3298da","1");
INSERT INTO secciones VALUES("10","","","b54a5f15ecd4dd7596afcd5d16fa62aa","1");
INSERT INTO secciones VALUES("11","","","70cfd62872f69371745a0b0d7b5c9bd1","1");
INSERT INTO secciones VALUES("12","Seccion Mariscona","1","2d5a695e","1");
INSERT INTO secciones VALUES("13","Seccion Mariscona 2","1","3596af8e","1");
INSERT INTO secciones VALUES("14","Seccion Mariscona","8","443df484","1");

-- ----------------------------------------------------- 
 -- Table `Iuteb_asignaturas`.`usuarios` 
 -- ----------------------------------------------------- 

DROP TABLE IF EXISTS usuarios;

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(45) DEFAULT NULL,
  `contrasena` int(11) DEFAULT NULL,
  `nombre_completo` varchar(45) DEFAULT NULL,
  `cedula` int(11) DEFAULT NULL,
  `correo` varchar(45) DEFAULT NULL,
  `fecha_ingreso` datetime DEFAULT CURRENT_TIMESTAMP,
  `telefono` int(11) DEFAULT NULL,
  `foto_perfil` varchar(450) DEFAULT NULL,
  `id_malla` int(11) DEFAULT NULL,
  `estado` enum('0','1') DEFAULT '1',
  `tipo` enum('Estudiante','Administrador','Profesor') DEFAULT 'Estudiante',
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `correo_UNIQUE` (`correo`),
  UNIQUE KEY `usuario_UNIQUE` (`usuario`),
  KEY `user_id_malla_idx` (`id_malla`),
  CONSTRAINT `user_id_malla` FOREIGN KEY (`id_malla`) REFERENCES `malla_curricular` (`id_malla`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

INSERT INTO usuarios VALUES("1","Admin","12345","Luis Precioso","25659843","admin@info.com","2017-09-21 20:07:12","4124981","grabatar.jpg","2","1","Administrador");
INSERT INTO usuarios VALUES("2","Adrian","123","Adrian Flores","20","adrian@gmail.com","2017-09-25 01:01:31","123456789","grabatar.jpg","","1","Estudiante");
INSERT INTO usuarios VALUES("3","Pedro","324","Jose Flores","","","2017-09-25 01:02:01","","grabatar.jpg","","1","Estudiante");
INSERT INTO usuarios VALUES("4","Yaciris","324","Luigi","","","2017-09-25 01:03:24","","grabatar.jpg","","1","Estudiante");
INSERT INTO usuarios VALUES("5","Vanessa","324","mARIO","","","2017-09-25 01:06:19","","grabatar.jpg","","1","Estudiante");
INSERT INTO usuarios VALUES("6","Michel","324","Maria Flores","","","2017-09-25 01:08:36","","grabatar.jpg","","1","Estudiante");
INSERT INTO usuarios VALUES("7","sadasdda","32432432","asdsa","3","d","2017-09-25 01:10:09","3","","1","1","Estudiante");
INSERT INTO usuarios VALUES("10","sadasddauih","32432432","asdsa","3","dc","2017-09-25 01:12:15","3","","1","1","Estudiante");
INSERT INTO usuarios VALUES("11","dsfdsf","435435","dsfds","","","2017-09-25 01:13:05","","","","1","Estudiante");
INSERT INTO usuarios VALUES("12","ygugu","68","g","7","g","2017-09-25 01:17:01","7","","1","1","Estudiante");
INSERT INTO usuarios VALUES("13","dfsfds","34543","dsfdsfdsf","","","2017-09-26 10:52:16","","","","1","Estudiante");
INSERT INTO usuarios VALUES("14","dsdsfds","43543","dsfdsf","","","2017-09-26 10:54:00","","","","1","Estudiante");
INSERT INTO usuarios VALUES("15","Manuel","32432432","asdsa","3","dcuy","2017-09-28 09:44:40","3","","1","1","Estudiante");
INSERT INTO usuarios VALUES("16","Manuelh","32432432","asdsa","37","dcuyhh","2017-09-28 09:46:22","3","","1","1","Estudiante");
INSERT INTO usuarios VALUES("17","Alejandro","324","asdsa","3733","dcuyhhddsd","2017-09-29 15:01:08","3","","1","1","Estudiante");
INSERT INTO usuarios VALUES("18","Alejandrodd","324","asdsadssd","373344","dcuyhhddsddd","2017-09-29 15:02:19","3","","1","1","Estudiante");
INSERT INTO usuarios VALUES("19","Alejandroddss","324","asdsadssd","37334433","dcuyhhddsddddsds","2017-09-29 15:04:51","3","","1","1","Estudiante");
INSERT INTO usuarios VALUES("20","Alejandroddssh","324","asdsadssd","2147483647","dcuyhhddsddddsdsh","2017-09-29 15:05:08","3","","1","1","Estudiante");
INSERT INTO usuarios VALUES("21","Prueba Token","1234","Prueba","123456789","a","2017-10-01 12:13:05","3","","1","1","Estudiante");

