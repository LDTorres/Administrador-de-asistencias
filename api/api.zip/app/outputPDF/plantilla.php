<!DOCTYPE html>
<html lang='en'>

<head>
  <meta charset='UTF-8'>
  <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
  <meta name='viewport' content='width=device-width, initial-scale=1.0'>
  <meta http-equiv='X-UA-Compatible' content='ie=edge'>
  <title>Reporte</title>
  <style>
    .text-center {
      text-align: center;
    }

    .mermbrete {
      margin: auto;
      display: block;
      width: 80%;
      height: 50px;
    }

    .datos> :first-child span.elemento {
      display: inline-block;
      margin-right: 30px;
    }

    .datos> :last-child .elemento {
      display: block;
    }

    .elemento {
      margin-top: 15px;
    }

    span.campo_subrayado {
      width: auto;
      padding: 0 8px;
      border-bottom: 1px solid black;
      min-width: 80px;
      display: inline-block;
    }

    span.elementoFirma {
      border-top: 1px solid black;
      padding: 0 8px;
      margin-top: 20px;
      display: -webkit-inline-box;
      display: -ms-inline-flexbox;
      display: inline-flex;
    }

    footer {
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      -ms-flex-pack: distribute;
      justify-content: space-around;
    }

    table {
      font-family: arial, sans-serif;
      border-collapse: collapse;
      font-size: 10px;
    }

    th,
    td {
      border: 1px solid black;
      padding: 4px;
    }

    .pivote th {
      height: 30px;
    }

  </style>

</head>

<body>
  <div>
    <img class='membrete' src='app/outputPDF/banner.png'>
    <div>
      <H4 class='text-center'>PROGRAMA NACIONAL DE FORMACIÓN EN ".$datos['datos']['seccion'][0]['nombreMalla']." (PNFI) CONTROL DE PLANIFICACIÓN
        Y ASISTENCIA</H4>
      <div class='datos'>
        <div>
          <div>
            <span class='elemento'>
              <span>Docente:</span>
              <span class='campo_subrayado'>".$datos['datos']['seccion'][0]['nombre_completo']."</span>
            </span>
            <span class='elemento'>
              <span>PNF:</span>
              <span class='campo_subrayado'>".$datos['datos']['seccion'][0]['nombreMalla']."</span>
            </span>
          </div>
          <div>
            <span class='elemento'>
              <span>Período Académico:</span>
              <span class='campo_subrayado'>".$datos['datos']['seccion'][0]['trimestre']."</span>
            </span>
          </div>
        </div>
        <div>
          <span class='elemento'>
            <span>Unidad Curricular:</span>
            <span class='campo_subrayado'>".$datos['datos']['seccion'][0]['nombre_asig']."</span>
          </span>
          <span class='elemento'>
            <span>Sección:</span>
            <span class='campo_subrayado'>".$datos['datos']['seccion'][0]['nombreSeccion']."</span>
          </span>
        </div>
      </div>
    </div>
    <div class='cuerpo'>
      <table>
        <thead>
          <tr class='pivote'>
            <th colspan='4' style='border:none;'></th>"; for($i = 0; $i
            <=$ encuentros; $i++): $content .="<th></th>" ; endfor; $content .="
                <th rowspan='3'>Total Asistencia</th>
                <th rowspan='3'>Porcentaje de Asistencias</th>
                <th rowspan='3'>Porcentaje de Insasistencias</th>
                </tr>
                <tr>
                <th colspan='4' style='border:none; text-align:right;'>OBJETIVOS FACILITADOS O EVALUADOS</th>" ; for($i=0
              ; $i <=$ encuentros; $i++): $content .="<th>C" .$i. ":</th>"; endfor; $content .="
                </tr>
                <tr>
                <th colspan='4' style='border:none; text-align:right;'>FECHA</th>" ; foreach($datos[ 'datos'][
              'encuentros'] as $key=> $v): $content .= "
              <th>".$v['fecha'].":</th>"; endforeach; $content .= "
          </tr>
          <tr>
            <th>Nº</th>
            <th>CEDULA</th>
            <th>APELLIDOS Y NOMBRES</th>
            <th>EDE</th>"; for($i = 0; $i
            <=$ encuentros; $i++): $content .="<th></th>" ; endfor; $content .="
                <th rowspan='2'></th>
                <th rowspan='2'></th>
                <th rowspan='2'></th>
                </tr>
            </thead>
            <tbody>
            " ; foreach ($datos[ 'datos'][ 'alumnos_seccion'] as $key=> $value) { $content .= "
              <tr>
                <td>".$key."</td>
                <td>".$value['cedula']."</td>
                <td>".$value['nombre_completo']."</td>
                <td>CMA</td>"; foreach ($datos['datos']['alumnos_seccion'][$key]['asistencias'] as $llave => $value) { $content
                .= "
                <td>".$value['asistio']."</td>"; } $content .= "
                <td>".$encuentros."</td>
                <td>".$datos['datos']['alumnos_seccion'][$key]['porcentaje_asistencias']."</td>
                <td>".$datos['datos']['alumnos_seccion'][$key]['porcentaje_inasistencias']."</td>
              </tr>"; } $content .= "
              <tr>
                <th colspan='3' style='border:none;'></th>
                <td style='border:none;'>Firma Vocero</td>"; for($i = 0; $i <=$ encuentros; $i++): $content .="<td></td>" ; endfor; $content .="
                </tr>
            </tbody>
            </table>
        </div>
        <div>
            <span class='elementoFirma'>Firma del Docente</span>
            <span class='elementoFirma'>Firma y Sello de la Coordinación que administra la Sección</span>
        </div>
</body>
</html>
